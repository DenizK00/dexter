#!/usr/bin/env python3
"""
Setup script for development installation of Dexter Toolkit
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
