"""
Script Name: test_distr.py
Author: Deniz
Created: 2024-07-09 14:47:30
Description: Unit Tests for Distribution class
"""



