"""
Core Module

Provides pipeline management and core utilities.
"""

from .pipeline import Pipeline

__all__ = ['Pipeline']
