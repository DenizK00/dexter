# from setuptools import setup, find_packages

# setup(
#     name='GridEnv',
#     version='0.1.0',
#     packages=find_packages(),
#     install_requires=[
#         'numpy',
#         'Pillow'
#     ],
#     author='Deniz',
#     author_email='denizkurtaran00@gmail.com',
#     description='A package for drawing 2D grid environments with a mouse.',
#     long_description=open('README.md').read(),
#     long_description_content_type='text/markdown',
#     url='https://github.com/yourusername/GridEnv',
#     classifiers=[
#         'Programming Language :: Python :: 3',
#         'License :: OSI Approved :: MIT License',
#         'Operating System :: OS Independent',
#     ],
# )
