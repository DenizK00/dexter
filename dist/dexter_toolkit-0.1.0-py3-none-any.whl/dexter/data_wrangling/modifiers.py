import dexter.stats as st


def diffuse(df, cols=list[str]):
    pass

def deviate(column:str, err_mean=0, err_variance=1): # Add heteroscedasticy
    pass
