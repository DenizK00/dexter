class SimulationPipeline:
    def __init__(self):
        pass