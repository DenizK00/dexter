import grid

grid.draw()